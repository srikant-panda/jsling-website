# JSling for Windows

`jsling.exe` is a standalone, statically-linked 64-bit Windows executable —
no installer needed, no MinGW/Visual C++ runtime required. Just download
and run.

## Usage (same as Node.js)

Open Command Prompt or PowerShell in the folder containing `jsling.exe`:

```cmd
jsling.exe script.js
jsling.exe -e "console.log(1 + 2)"
jsling.exe
```

- `jsling.exe script.js` — run a JavaScript file
- `jsling.exe -e "code"` — run an inline snippet
- `jsling.exe` (no args) — interactive REPL

## Run from anywhere (optional)

To use `jsling` from any folder without typing the full path, add the folder
containing `jsling.exe` to your PATH:

1. Press `Win + R`, type `sysdm.cpl`, press Enter.
2. Go to **Advanced** → **Environment Variables**.
3. Under "User variables", select `Path` → **Edit** → **New**.
4. Add the full path to the folder containing `jsling.exe`.
5. Open a new terminal — you can now run `jsling script.js` from anywhere.

(Or in PowerShell, for the current session only:)
```powershell
$env:PATH += ";C:\path\to\folder"
```

## Notes

- Built via MinGW-w64 cross-compilation from the same C++17 source as the
  Linux build (`COMPILER_CPP/`), statically linked — only depends on
  `KERNEL32.dll` and `msvcrt.dll`, which ship with every Windows install.
- If Windows SmartScreen flags it (common for unsigned/new executables),
  click "More info" → "Run anyway". This is normal for unsigned binaries
  and not an indication of a problem with the file.
